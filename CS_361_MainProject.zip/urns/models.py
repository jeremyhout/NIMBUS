from pydantic import BaseModel
from typing import Optional, Dict, Any


class ReminderIn(BaseModel):
    app_id: str
    type: str # "time" | "cron"
    when: Optional[str] = None # ISO8601 when type=="time"
    cron: Optional[str] = None # when type=="cron"
    payload: Dict[str, Any]
    notify: Dict[str, Optional[str]] # {"webhook": URL or None}
    idempotency_key: Optional[str] = None


class ReminderOut(BaseModel):
    reminder_id: str


class Reminder(BaseModel):
    id: str
    app_id: str
    type: str
    when: Optional[str] = None
    cron: Optional[str] = None
    payload: Dict[str, Any]
    notify: Dict[str, Optional[str]]