import asyncio
import uuid
from datetime import datetime
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from dateutil import parser as dtparse
import httpx


scheduler = AsyncIOScheduler()


async def deliver_webhook(url: str, payload: dict):
    async with httpx.AsyncClient(timeout=10) as client:
        await client.post(url, json=payload)


def schedule_time(reminder_id: str, when_iso: str, webhook: str, payload: dict):
    dt = dtparse.isoparse(when_iso)
    def _job():
        asyncio.create_task(deliver_webhook(webhook, {
            "title": payload.get("title","Reminder"),
            "msg": payload.get("msg","(no message)"),
            "fired_at": datetime.utcnow().isoformat()
        }))
    scheduler.add_job(_job, 'date', run_date=dt, id=reminder_id, replace_existing=True)


def schedule_cron(reminder_id: str, cron_expr: str, webhook: str, payload: dict):
    trig = CronTrigger.from_crontab(cron_expr)
    def _job():
        asyncio.create_task(deliver_webhook(webhook, {
            "title": payload.get("title","Reminder"),
            "msg": payload.get("msg","(no message)"),
            "fired_at": datetime.utcnow().isoformat()
        }))
    scheduler.add_job(_job, trig, id=reminder_id, replace_existing=True)