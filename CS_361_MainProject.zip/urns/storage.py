from typing import Dict
from .models import Reminder


# Minimal in-memory store for Sprint 1 (replace with SQLite later)
_STORE: Dict[str, Reminder] = {}


def save(rem: Reminder):
    _STORE[rem.id] = rem


def get(rem_id: str) -> Reminder | None:
    return _STORE.get(rem_id)


def list_by_app(app_id: str):
    return [r for r in _STORE.values() if r.app_id == app_id]


def delete(rem_id: str):
    _STORE.pop(rem_id, None)