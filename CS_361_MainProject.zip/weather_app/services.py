
import httpx
from .errors import ValidationError, UpstreamError


USER_AGENT = {"User-Agent": "SE-WeatherApp/1.0 (class project)"}


async def geocode_city(city: str):
    """Return up to 5 candidate places with state/admin1 so users can disambiguate."""
    url = "https://geocoding-api.open-meteo.com/v1/search"
    params = {"name": city, "count": 5}
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(url, params=params, headers=USER_AGENT)
            r.raise_for_status()
            data = r.json()
            results = data.get("results") or []
            if not results:
                raise ValidationError("City not found. Please check the spelling.")

            matches = []
            for res in results:
                matches.append({
                    "name": res.get("name"),
                    "admin1": res.get("admin1"),                # state/region
                    "country": res.get("country"),
                    "country_code": res.get("country_code"),
                    "lat": res.get("latitude"),
                    "lon": res.get("longitude"),
                })
            return matches
    except httpx.HTTPError as e:
        raise UpstreamError(f"Geocoding failed: {e}")



async def fetch_current_weather(lat: float, lon: float):
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": lon,
        "current_weather": True,
        "hourly": "precipitation_probability",
    }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(url, params=params, headers=USER_AGENT)
            r.raise_for_status()
            j = r.json()
            cw = j.get("current_weather") or {}
            return {
                "temperature_c": cw.get("temperature"),
                "windspeed": cw.get("windspeed"),
                "weathercode": cw.get("weathercode"),
                "time": cw.get("time"),
            }
    except httpx.HTTPError as e:
        raise UpstreamError(f"Weather provider error: {e}")


async def fetch_5day_forecast(lat: float, lon: float):
    """Return 5 daily entries with date, high/low, precip prob if available."""
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": lon,
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
        "timezone": "auto",
    }
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(url, params=params, headers=USER_AGENT)
            r.raise_for_status()
            j = r.json()
            days = []
            d = j.get("daily") or {}
            for i in range(min(5, len(d.get("time", [])))):
                days.append({
                    "date": d["time"][i],
                    "temp_max_c": d["temperature_2m_max"][i],
                    "temp_min_c": d["temperature_2m_min"][i],
                    "precip_prob": (d.get("precipitation_probability_max") or [None])[i],
                })
            return days
    except httpx.HTTPError as e:
        raise UpstreamError(f"Forecast provider error: {e}")
