class ValidationError(Exception):
    pass


class UpstreamError(Exception):
    pass